package kuehne.nagel.sql;

public enum SQLQueryType {
    SEARCH_QUERY,
    SAVE_QUERY,
    UPDATE_QUERY,
}
